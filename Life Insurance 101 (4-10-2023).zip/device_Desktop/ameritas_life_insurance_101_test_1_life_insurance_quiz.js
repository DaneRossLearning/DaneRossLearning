if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 1.93268e-12px; width: 1009px; height: 80px; z-index: 10; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,1.9326762412674725e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 1.93268e-12px; width: 1009px; height: 80px; z-index: 11; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,1.9326762412674725e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 4.54747e-13px; width: 229px; height: 80px; z-index: 12; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999998,4.547473508864641e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 13;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 14; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
text139746.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink139747()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 1;",
	cssClasses:	"",
	id:		"139746",
	htmlId:		"tobj139746",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og138019.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138019",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
image141018.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141018Img\" src=\"images/Background%20-%20Test%20Questions.JPG\" alt=\"Background - Test Questions\" title=\"Background - Test Questions\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 672px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 672px; z-index: 2; border-radius: 0px;",
	cssClasses:	"",
	id:		"141018",
	htmlId:		"tobj141018",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background - Test Questions"
	},
	objData:	{"a":[0,288,0,[0,0,1009,672]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":672}}
};
shape138021.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138021inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 331)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138021",
	htmlId:		"tobj138021",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Color"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138022.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138022inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_137997_331\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(504.5 331)\" style=\"\">\n	<pattern id=\"SVGID_137997_331\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_137997_331&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 4; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138022",
	htmlId:		"tobj138022",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138023.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138023inner\"><svg viewBox=\"0 0 1010 166\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(505 83)\" style=\"\">\n	<path d=\"M 0 0 L 1010 166 L 0 166 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: 1, 2; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-505, -83) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(505 83) matrix(-1 0 0 1 0 0) \">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-503\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 496px; width: 1010px; height: 166px; z-index: 5; transform: scaleX(-1); overflow: visible; pointer-events: none;; behavior:url(-ms-transform.htc); -moz-transform: ScaleX(-1); -webkit-transform: ScaleX(-1); -o-transform: ScaleX(-1); -ms-transform: ScaleX(-1); filter: fliph; -ms-filter: fliph",
	cssClasses:	"",
	id:		"138023",
	htmlId:		"tobj138023",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Overlay_Bottom"
	},
	objData:	{"a":[0,4640,0,[0,496.0000000000001,1010,166]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":166,"width":1010,"height":166},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text138007.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 910px; min-height: 125px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 900px; min-height: 115px;\"><h1><p style=\"text-align: center;\" lang=\"en\"><strong><span style=\"color:#ffffff;font-family:fira sans;font-size:60pt;\"><span class='VarCurrentPageName'>" +  VarCurrentPageName.getValueForDisplay() + "</span></span></strong></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 50px; top: 145px; width: 910px; height: 125px; z-index: 6;",
	cssClasses:	"",
	id:		"138007",
	htmlId:		"tobj138007",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,32,0,[50,145,910,125]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":50,"y":145,"width":910,"height":125},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138006.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 909px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 909px; min-height: 100px;\"><h2><p align=\"center\" style=\"margin-left:0px;text-indent:0px;line-height:1.168;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:18pt;\">Read each question carefully and thoroughly before anwering. Then, select the BEST answer from the choices provided. </span></p></h2></div></div>",
	cssText:	"left: 50px; top: 275px; visibility: hidden; position: absolute; width: 909px; height: 100px; z-index: 7;",
	cssClasses:	"",
	id:		"138006",
	htmlId:		"tobj138006",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content"
	},
	objData:	{"a":[32,32,[35,0,9,0,100,0],[50,275,909,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":50,"y":275,"width":909,"height":100},"dwTextFlags":131072,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton138008.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138008inner\"><svg viewBox=\"0 0 210 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(105 25)\" style=\"\">\n	<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(105 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(211,34,42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-33.02\" y=\"7.56\" fill=\"#d3222a\">BEGIN</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 400px; top: 455px; width: 210px; height: 50px; z-index: 8; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138008",
	htmlId:		"tobj138008",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Begin Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('ameritas_life_insurance_101_test_1_question_1_true_false.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[400,455,210,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":400,"y":455,"width":210,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(211,34,42); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-33.02\" y=\"7.56\" fill=\"#d3222a\">BEGIN</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-33.02\" y=\"7.56\" fill=\"#FFFFFF\">BEGIN</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-33.02\" y=\"7.56\" fill=\"#FFFFFF\">BEGIN</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-33.02\" y=\"7.56\" fill=\"#28283C\">BEGIN</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"BEGIN","titleValue":"BEGIN"}
};
text141337.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 9;",
	cssClasses:	"",
	id:		"141337",
	htmlId:		"tobj141337",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	16
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Background%20-%20Test%20Questions.JPG","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];
