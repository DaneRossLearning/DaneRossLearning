if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 7.24754e-13px; width: 1009px; height: 80px; z-index: 25; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,7.247535904753022e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 7.24754e-13px; width: 1009px; height: 80px; z-index: 26; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,7.247535904753022e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 1.7053e-13px; width: 229px; height: 80px; z-index: 27; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999999,1.7053025658242404e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 28;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 29; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
og270.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og270",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":true}
};
textbutton281.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj281inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_140117_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_283&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 930px; top: 592px; width: 44px; height: 44px; z-index: 30; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"281",
	htmlId:		"tobj281",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Next',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_types_of_term_life.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[930,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":79,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_283&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_285\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_285&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_287\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_287&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_289\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_289&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Next","titleValue":"Next"}
};
textbutton275.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj275inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_140117_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_291&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 879px; top: 592px; width: 44px; height: 44px; z-index: 31; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"275",
	htmlId:		"tobj275",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Back",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Previous',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_more_needs_met_by_life_insurance.html',false,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[879,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_291&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_293\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_293&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_295\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_295&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140117_43_297\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140117_43_297&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Back","titleValue":"Back"}
};
og140118.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140118",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og140122.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140122",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og140128.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140128",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og140139.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140139",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
text140141.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 930px; min-height: 90px;\"><p lang=\"en\"><span style=\"color: rgb(178, 13, 21); font-family: Questrial, sans-serif; font-size:48pt;\">Types of Life Insurance</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 40px; top: 100px; width: 940px; height: 100px; z-index: 1;",
	cssClasses:	"",
	id:		"140141",
	htmlId:		"tobj140141",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,32,0,[40,100,940,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":100,"width":940,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140140.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140140",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
text140142.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 934px; min-height: 93px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 934px; min-height: 93px;\"><p style=\"margin-left: 0px; text-indent: 0px; margin-top: 0px; margin-bottom: 0px;\" lang=\"en\"><span style=\"font-size:14pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">Life insurance provides a payment to your beneficiaries if you were to die referred to as the policy\'s death benefit.&nbsp;</span><span style=\"font-family: Questrial, sans-serif; font-size: 18.6667px; color: rgb(178, 13, 21);\">Generally, life&nbsp;insurance coverage is grouped into one of two categories: temporary or permanent.</span></p>\n\n<p style=\"margin-left: 0px; text-indent: 0px; margin-top: 0px; margin-bottom: 0px;\"><span style=\"font-family: Questrial, sans-serif; font-size: 18.6667px; color: rgb(178, 13, 21);\">​</span></p>\n\n<p style=\"margin-left: 0px; text-indent: 0px; margin-top: 0px; margin-bottom: 0px;\"><span style=\"color: rgb(0, 0, 0); font-family: Questrial, sans-serif; font-size: 18.6667px;\">Click on each of the types of insurance to learn more</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 40px; top: 193px; width: 934px; height: 93px; z-index: 2;",
	cssClasses:	"",
	id:		"140142",
	htmlId:		"tobj140142",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Subtitle"
	},
	objData:	{"a":[0,32,0,[40,193,934,93]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":193,"width":934,"height":93},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140143.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140143",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140144.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140144inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-61.66\" y=\"7.56\" fill=\"#ffffff\">TERM LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 34px; top: 299px; width: 212px; height: 52px; z-index: 3; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140144",
	htmlId:		"tobj140144",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button1",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140144.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFRAMEWORK_C2R4_Tab1.set('1');  triv$('span.VarFRAMEWORK_C2R4_Tab1', getDisplayDocument()).html(VarFRAMEWORK_C2R4_Tab1.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140153.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140216.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32800,0,[34,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#ffffff\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#0a1472\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#0a1472\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#ffffff\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"TERM LIFE","titleValue":"TERM LIFE"}
};
textbutton140153.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140153inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-61.66\" y=\"7.56\" fill=\"#b20d15\">TERM LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 34px; top: 299px; width: 212px; height: 52px; z-index: 4; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140153",
	htmlId:		"tobj140153",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button1_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140153.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140216.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[34,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#b20d15\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#0a1472\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#0a1472\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-61.66\" y=\"7.56\" fill=\"#0a1472\">TERM LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"TERM LIFE","titleValue":"TERM LIFE"}
};
og140160.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140160",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140161.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140161inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-71.65\" y=\"7.56\" fill=\"#ffffff\">WHOLE LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 276px; top: 299px; width: 212px; height: 52px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140161",
	htmlId:		"tobj140161",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button2",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140161.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFRAMEWORK_C2R4_Tab2.set('1');  triv$('span.VarFRAMEWORK_C2R4_Tab2', getDisplayDocument()).html(VarFRAMEWORK_C2R4_Tab2.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140170.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140219.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32800,0,[276,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":277,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#ffffff\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#0a1472\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#0a1472\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#ffffff\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"WHOLE LIFE","titleValue":"WHOLE LIFE"}
};
textbutton140170.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140170inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-71.65\" y=\"7.56\" fill=\"#b20d15\">WHOLE LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 276px; top: 299px; width: 212px; height: 52px; z-index: 6; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140170",
	htmlId:		"tobj140170",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button2_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140170.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140219.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[276,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":277,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#b20d15\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#0a1472\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#0a1472\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-71.65\" y=\"7.56\" fill=\"#0a1472\">WHOLE LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"WHOLE LIFE","titleValue":"WHOLE LIFE"}
};
og140177.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140177",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140178.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140178inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-96.33\" y=\"7.56\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 514px; top: 299px; width: 212px; height: 52px; z-index: 7; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140178",
	htmlId:		"tobj140178",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button3",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140178.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFRAMEWORK_C2R4_Tab3.set('1');  triv$('span.VarFRAMEWORK_C2R4_Tab3', getDisplayDocument()).html(VarFRAMEWORK_C2R4_Tab3.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140187.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140222.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32800,0,[514,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":515,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"UNIVERSAL LIFE","titleValue":"UNIVERSAL LIFE"}
};
textbutton140187.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140187inner\"><svg viewBox=\"0 0 212 52\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 26)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 26)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-96.33\" y=\"7.56\" fill=\"#b20d15\">UNIVERSAL LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 514px; top: 299px; width: 212px; height: 52px; z-index: 8; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140187",
	htmlId:		"tobj140187",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button3_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140187.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140222.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[514,299,212,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":515,"y":300,"width":212,"height":52},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#b20d15\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 26)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 50 L 0 50 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 26)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-96.33\" y=\"7.56\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"UNIVERSAL LIFE","titleValue":"UNIVERSAL LIFE"}
};
og140194.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140194",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140195.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140195inner\"><svg viewBox=\"0 0 212 62\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 31)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 31)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#ffffff\">VARIABLE</tspan>\n			<tspan x=\"-96.33\" y=\"23.29\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 759px; top: 292px; width: 212px; height: 62px; z-index: 9; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140195",
	htmlId:		"tobj140195",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button4",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140195.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFRAMEWORK_C2R4_Tab4.set('1');  triv$('span.VarFRAMEWORK_C2R4_Tab4', getDisplayDocument()).html(VarFRAMEWORK_C2R4_Tab4.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140204.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140225.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32800,0,[759,292,212,62]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":760,"y":293,"width":212,"height":62},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#ffffff\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#0a1472\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#0a1472\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(178, 13, 21); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#ffffff\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#ffffff\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"VARIABLE UNIVERSAL LIFE","titleValue":"VARIABLE UNIVERSAL LIFE"}
};
textbutton140204.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140204inner\"><svg viewBox=\"0 0 212 62\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(106 31)\" style=\"\">\n	<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(106 31)\">\n		<text font-family=\"\'Questrial\',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#b20d15\">VARIABLE</tspan>\n			<tspan x=\"-96.33\" y=\"23.29\" fill=\"#b20d15\">UNIVERSAL LIFE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 759px; top: 292px; width: 212px; height: 62px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140204",
	htmlId:		"tobj140204",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button4_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og140122.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140128.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140204.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140225.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[759,292,212,62]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":760,"y":293,"width":212,"height":62},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(178, 13, 21); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(178,13,21); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#b20d15\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#b20d15\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#0a1472\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(206, 208, 227); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#0a1472\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(106 31)\" style=\"\">\n\t<path d=\"M 0 0 L 210 0 L 210 60 L 0 60 L 0 0 Z\" style=\"stroke: rgb(10, 20, 114); stroke-width: 2; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(106 31)\">\n\t\t<text font-family=\"'Questrial',Questrial\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(10,20,114); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-60.66\" y=\"-8.17\" fill=\"#0a1472\">VARIABLE</tspan>\n\t\t\t<tspan x=\"-96.33\" y=\"23.29\" fill=\"#0a1472\">UNIVERSAL LIFE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"VARIABLE UNIVERSAL LIFE","titleValue":"VARIABLE UNIVERSAL LIFE"}
};
og140216.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140216",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape140267.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140267inner\"><svg viewBox=\"0 0 971 285\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(485.5 142.5)\" style=\"\">\n	<path d=\"M 0 0 L 971 0 L 971 285 L 0 285 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(221, 221, 221); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-485.5, -142.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(485.5 142.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 28px; top: 362px; width: 971px; height: 285px; z-index: 11; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140267",
	htmlId:		"tobj140267",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 2"
	},
	objData:	{"a":[0,0,0,[27.999999999999943,362.0000000000001,971,285]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":28,"y":362,"width":971,"height":285},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 2","titleValue":"Rectangle 2"}
};
text140217.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 50px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: Arial, sans-serif; color: black; font-size:28pt;\"><u>Term L</u><u>ife I</u><u>nsurance</u><span style=\"color:#c0392b;\">&nbsp;</span></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 369px; width: 940px; height: 50px; z-index: 12;",
	cssClasses:	"",
	id:		"140217",
	htmlId:		"tobj140217",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab1"
	},
	objData:	{"a":[0,0,0,[40,369,940,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":369,"width":940,"height":50},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140218.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 223px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 223px;\"><p lang=\"en\"><span style=\"font-size:16pt; color: rgb(192, 57, 43); font-family: Arial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;Term insurance protects your loved ones for the number of years you choose. It’s the most affordable type of life insurance and makes sense when your need for coverage will disappear at some point, such as when your children graduate from college or when a debt is paid off.</span></p>\n\n<p><span style=\"font-size:16pt; color: rgb(192, 57, 43); font-family: Arial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;Many term products are renewable. After each term, policy owners have the opportunity to extend coverage for an additional period of time. At this renewal point the premium payment will most likely increase substantially.</span></p>\n\n<p><span style=\"font-size:16pt; color: rgb(192, 57, 43); font-family: Arial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;Term insurance may also have the option to convert the policy to a whole or universal </span></p>\n\n<p><span><span style=\"font-size:16pt; color: rgb(192, 57, 43); font-family: Arial, sans-serif;\">policy without providing additional evidence of insurability.&nbsp;</span></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 424px; width: 940px; height: 223px; z-index: 13;",
	cssClasses:	"",
	id:		"140218",
	htmlId:		"tobj140218",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab1"
	},
	objData:	{"a":[0,0,0,[40,424,940,223]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":424,"width":940,"height":223},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140219.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140219",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape140268.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140268inner\"><svg viewBox=\"0 0 971 285\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(485.5 142.5)\" style=\"\">\n	<path d=\"M 0 0 L 971 0 L 971 285 L 0 285 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(221, 221, 221); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-485.5, -142.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(485.5 142.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 28px; top: 362px; width: 971px; height: 285px; z-index: 14; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140268",
	htmlId:		"tobj140268",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 2"
	},
	objData:	{"a":[0,0,0,[27.999999999999943,362.0000000000001,971,285]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":28,"y":362,"width":971,"height":285},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 2","titleValue":"Rectangle 2"}
};
text140220.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 50px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: Arial, sans-serif; font-size:28pt; color: black;\"><u>Whole Life I</u><u>nsurance</u>&nbsp;</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 369px; width: 940px; height: 50px; z-index: 15;",
	cssClasses:	"",
	id:		"140220",
	htmlId:		"tobj140220",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab2"
	},
	objData:	{"a":[0,0,0,[40,369,940,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":369,"width":940,"height":50},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140221.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 929px; min-height: 213px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 929px; min-height: 213px;\"><p lang=\"en\"><span style=\"font-size:16pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;Permanent life insurance is designed to protect for a lifetime. It can build cash value, which helps make it a flexible financial planning tool. The cash value can be used for a variety of needs, such as paying for college tuition or supplementing retirement income.</span></p>\n\n<p><span style=\"font-size:16pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">​&nbsp;&nbsp;&nbsp;&nbsp;Whole life features guaranteed premiums, death benefits and cash value.* The cash value may accumulate tax-deferred over time. Whole life insurance policies also give you the potential to receive dividends, which can increase the cash value of the policy when the insured is living or provide an increased death benefit&nbsp; for your beneficiaries.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 424px; width: 929px; height: 213px; z-index: 16;",
	cssClasses:	"",
	id:		"140221",
	htmlId:		"tobj140221",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab2"
	},
	objData:	{"a":[0,0,0,[40,424,929,213]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":424,"width":929,"height":213},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140235.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 22px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 22px;\"><p lang=\"en\"><span style=\"font-size:12pt; font-family:Arial,sans-serif; color:rgb(0,0,0)\">* Guarantees are based on the claims paying ability of the issuing company.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 625px; width: 940px; height: 22px; z-index: 17;",
	cssClasses:	"",
	id:		"140235",
	htmlId:		"tobj140235",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab2"
	},
	objData:	{"a":[0,0,0,[40,625,940,22]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":625,"width":940,"height":22},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140222.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140222",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape140272.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140272inner\"><svg viewBox=\"0 0 971 263\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(485.5 131.5)\" style=\"\">\n	<path d=\"M 0 0 L 971 0 L 971 263 L 0 263 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(221, 221, 221); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-485.5, -131.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(485.5 131.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 28px; top: 362px; width: 971px; height: 263px; z-index: 18; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140272",
	htmlId:		"tobj140272",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 2"
	},
	objData:	{"a":[0,0,0,[27.999999999999943,362.0000000000001,971,263]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":28,"y":362,"width":971,"height":263},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 2","titleValue":"Rectangle 2"}
};
text140223.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 50px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: Arial, sans-serif; font-size:28pt; color: black;\"><u>Universal L</u><u>ife I</u><u>nsurance</u></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 371px; width: 940px; height: 50px; z-index: 19;",
	cssClasses:	"",
	id:		"140223",
	htmlId:		"tobj140223",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab3"
	},
	objData:	{"a":[0,0,0,[40,371,940,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":371,"width":940,"height":50},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140224.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 220px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 220px;\"><p lang=\"en\"><span style=\"font-size:14pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">Universal insurance policies are flexible and may allow you to raise or lower your premium or coverage amounts throughout your lifetime. Like whole life insurance, universal life also has a tax-deferred savings component, which may build wealth over time. There are a few variations to the traditional fixed universal life products:</span></p>\n\n<p><span style=\"font-size:14pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">​</span></p>\n\n<p><span style=\"font-size:16pt;\"><span style=\"font-family: Questrial, sans-serif; color: rgb(178, 13, 21);\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Indexed universal life&nbsp;<br>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Guaranteed universal life </span></span></p>\n\n<p><span style=\"font-size:16pt;\"><span style=\"font-family: Questrial, sans-serif; color: rgb(178, 13, 21);\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Survivorship universal life (second-to-die)<br>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• First-to-die life insurance </span></span></p>\n\n<p><span style=\"font-size:14pt; font-family:Questrial, sans-serif; color:rgb(178, 13, 21)\">​</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 426px; width: 940px; height: 220px; z-index: 20;",
	cssClasses:	"",
	id:		"140224",
	htmlId:		"tobj140224",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab3"
	},
	objData:	{"a":[0,0,0,[40,426,940,220]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":426,"width":940,"height":220},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140225.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140225",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape140276.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140276inner\"><svg viewBox=\"0 0 971 218\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(485.5 109)\" style=\"\">\n	<path d=\"M 0 0 L 971 0 L 971 218 L 0 218 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(221, 221, 221); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-485.5, -109) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(485.5 109)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 28px; top: 362px; width: 971px; height: 218px; z-index: 21; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140276",
	htmlId:		"tobj140276",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 2"
	},
	objData:	{"a":[0,0,0,[28,362.0000000000001,971,218]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":28,"y":362,"width":971,"height":218},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 2","titleValue":"Rectangle 2"}
};
text140226.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 50px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: Arial, sans-serif; font-size:28pt; color: black;\"><u>Variable </u><u>Universal L</u><u>ife I</u><u>nsurance</u></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 374px; width: 940px; height: 50px; z-index: 22;",
	cssClasses:	"",
	id:		"140226",
	htmlId:		"tobj140226",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab4"
	},
	objData:	{"a":[0,0,0,[40,374,940,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":374,"width":940,"height":50},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140227.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 940px; min-height: 140px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 940px; min-height: 140px;\"><p lang=\"en\"><span style=\"font-size:16pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;Variable universal life combines life insurance protection and an investment opportunity in one product. With the ability to invest in professionally managed investment options, you can potentially accumulate cash value while providing your family with death benefit protection.​</span></p>\n\n<p><span style=\"font-size:16pt; color: rgb(178, 13, 21); font-family: Questrial, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;This is a long term investment for clients who are looking for death benefit protection along with the diversity and flexibility of the various subaccounts and can also accept the volatility and risk.&nbsp;</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 40px; top: 429px; width: 940px; height: 140px; z-index: 23;",
	cssClasses:	"",
	id:		"140227",
	htmlId:		"tobj140227",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab4"
	},
	objData:	{"a":[0,0,0,[40,429,940,140]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":40,"y":429,"width":940,"height":140},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text141287.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 24;",
	cssClasses:	"",
	id:		"141287",
	htmlId:		"tobj141287",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	6
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Nav%20Button%20Left.png","images/Nav%20Button%20Right.png","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#ffffff","",0,0,1];
