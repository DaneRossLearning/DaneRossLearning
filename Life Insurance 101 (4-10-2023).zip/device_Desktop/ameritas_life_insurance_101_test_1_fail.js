if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.77822e-12px; width: 1009px; height: 80px; z-index: 14; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.7782220968219917e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.77822e-12px; width: 1009px; height: 80px; z-index: 15; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.7782220968219917e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 6.53699e-13px; width: 229px; height: 80px; z-index: 16; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999997,6.536993168992922e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 17;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 18; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
text139781.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink139782()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 1;",
	cssClasses:	"",
	id:		"139781",
	htmlId:		"tobj139781",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og138410.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138410",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
image138411.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj138411Img\" src=\"images/stock-photo-blurred-city-and-people-urba-1233391.jpg\" alt=\"\" title=\"\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 673px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 673px; z-index: 2; border-radius: 0px;",
	cssClasses:	"",
	id:		"138411",
	htmlId:		"tobj138411",
	bInsAnc:	0,
	cwObj:		{
		"name":	"stock-photo-blurred-city-and-people-urba-1233391"
	},
	objData:	{"a":[0,800,0,[0,0,1009,673]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":673}}
};
shape138412.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138412inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_137961_345\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(504.5 331)\" style=\"\">\n	<pattern id=\"SVGID_137961_345\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_137961_345&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138412",
	htmlId:		"tobj138412",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138413.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138413inner\"><svg viewBox=\"0 0 1009 370\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 185)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 370 L 0 370 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -185) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 185)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 185px; width: 1009px; height: 370px; z-index: 4; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138413",
	htmlId:		"tobj138413",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Color"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,185.0000000000001,1009,370]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":185,"width":1009,"height":370},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
image138483.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj138483Img\" src=\"images/Fira_VectorGraphics_QuizResults_Incorrect.png\" alt=\"\" title=\"\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 241px; height: 323px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 42px; top: 202px; width: 241px; height: 323px; z-index: 5; border-radius: 0px;",
	cssClasses:	"",
	id:		"138483",
	htmlId:		"tobj138483",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Fira_VectorGraphics_QuizResults_Incorrect"
	},
	objData:	{"a":[0,800,0,[42,202,241,323]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":42,"y":202,"width":241,"height":323}}
};
shape138484.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138484inner\"><svg viewBox=\"0 0 3 278\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(1.5 139)\" style=\"\">\n	<path d=\"M 0 0 L 0 275\" style=\"stroke: rgb(255, 255, 255); stroke-width: 3; stroke-dasharray: 1, 4; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(0, -137.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(8.5 139)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 688.5px; top: 233.5px; width: 3px; height: 278px; z-index: 6; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138484",
	htmlId:		"tobj138484",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Line"
	},
	objData:	{"a":[0,544,0,[688.5,233.5,3,278]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":690,"y":235,"width":3,"height":278},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text138487.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 325px; min-height: 45px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 325px; min-height: 45px;\"><p style=\"margin-left: 0px; text-indent: 0px; margin-top: 0px; margin-bottom: 0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif;\"><span style=\"font-size:20pt; color: rgb(255, 255, 255);\">Your Score:</span><span style=\"background-color: transparent; color: rgb(0, 0, 0); font-size:20pt;\"> </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 325px; top: 245px; width: 325px; height: 45px; z-index: 7;",
	cssClasses:	"",
	id:		"138487",
	htmlId:		"tobj138487",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Your Score Text",
		"arChld":
	[
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ text138487.changeContents( "Your Score: " +  Test_1_Score.getValueForDisplay() + "%" ); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[32,32,0,[325,245,325,45]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":325,"y":245,"width":325,"height":45},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138489.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 325px; min-height: 42px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 325px; min-height: 42px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, Fira; color: rgb(255, 255, 255); font-size:20pt;\">Passing Score: 80%</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 325px; top: 282px; width: 325px; height: 42px; z-index: 8;",
	cssClasses:	"",
	id:		"138489",
	htmlId:		"tobj138489",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Passing Score Text"
	},
	objData:	{"a":[0,32,0,[325,282,325,42]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":325,"y":282,"width":325,"height":42},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138490.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 346px; min-height: 69px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 346px; min-height: 69px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.273;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><strong><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:36pt;\">TRY AGAIN</span></strong></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 325px; top: 340px; width: 346px; height: 69px; z-index: 9;",
	cssClasses:	"",
	id:		"138490",
	htmlId:		"tobj138490",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Try Again Text "
	},
	objData:	{"a":[0,32,0,[325,340,346,69]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":325,"y":340,"width":346,"height":69},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138491.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 365px; min-height: 105px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 365px; min-height: 105px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.168;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, Fira; color: rgb(255, 255, 255); font-size:18pt;\">You have completed the quiz. </span></p>\n\n<p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\"><span style=\"font-family: &quot;Fira Sans&quot;, Fira; color: rgb(255, 255, 255); font-size:18pt;\">Press continue to move on. </span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 325px; top: 420px; width: 365px; height: 105px; z-index: 10;",
	cssClasses:	"",
	id:		"138491",
	htmlId:		"tobj138491",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Directions Text"
	},
	objData:	{"a":[0,32,0,[325,420,365,105]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":325,"y":420,"width":365,"height":105},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton138485.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138485inner\"><svg viewBox=\"0 0 198 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(99 25)\" style=\"\">\n	<path d=\"M 25 0 L 173 0 A 25 25 0 0 1 198 25 L 198 25 A 25 25 0 0 1 173 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-99, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(99 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(211,34,42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-55.52\" y=\"7.56\" fill=\"#d3222a\">CONTINUE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 755px; top: 350px; visibility: hidden; position: absolute; width: 198px; height: 50px; z-index: 11; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138485",
	htmlId:		"tobj138485",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Continue Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('ameritas_life_insurance_101_test_1_life_insurance_quiz.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[36,33312,[36,0,7,0,0,0,755,350,6,0],[755,350,198,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":755,"y":350,"width":198,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(99 25)\" style=\"\">\n\t<path d=\"M 25 0 L 173 0 A 25 25 0 0 1 198 25 L 198 25 A 25 25 0 0 1 173 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-99, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(99 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(211,34,42); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#d3222a\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(99 25)\" style=\"\">\n\t<path d=\"M 25 0 L 173 0 A 25 25 0 0 1 198 25 L 198 25 A 25 25 0 0 1 173 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-99, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(99 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(99 25)\" style=\"\">\n\t<path d=\"M 25 0 L 173 0 A 25 25 0 0 1 198 25 L 198 25 A 25 25 0 0 1 173 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-99, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(99 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(99 25)\" style=\"\">\n\t<path d=\"M 25 0 L 173 0 A 25 25 0 0 1 198 25 L 198 25 A 25 25 0 0 1 173 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-99, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(99 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#28283C\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
shape141370.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj141370inner\"><svg viewBox=\"0 0 292 13\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(146 6.5)\" style=\"\">\n	<path d=\"M 0 0 L 292 0 L 292 13 L 0 13 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35); pointer-events: auto;\" transform=\"translate(0 0) translate(-146, -6.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(146 7)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 352px; top: 647px; width: 292px; height: 13px; z-index: 12; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"141370",
	htmlId:		"tobj141370",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,32,0,[352,647,292,13]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":352,"y":647,"width":292,"height":13},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle","titleValue":"Rectangle"}
};
text141369.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 13;",
	cssClasses:	"",
	id:		"141369",
	htmlId:		"tobj141369",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	23
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Fira_VectorGraphics_QuizResults_Incorrect.png","images/stock-photo-blurred-city-and-people-urba-1233391.jpg","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];
