if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 9.66338e-13px; width: 1009px; height: 80px; z-index: 17; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,9.663381206337363e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 9.66338e-13px; width: 1009px; height: 80px; z-index: 18; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,9.663381206337363e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 2.27374e-13px; width: 229px; height: 80px; z-index: 19; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999999,2.2737367544323206e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 20;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 21; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
og270.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og270",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":true}
};
textbutton281.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj281inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_140280_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_283&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 930px; top: 592px; width: 44px; height: 44px; z-index: 22; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"281",
	htmlId:		"tobj281",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Next',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_types_of_permanent_life.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[930,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":79,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_283&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_285\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_285&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_287\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_287&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_289\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_289&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Next","titleValue":"Next"}
};
textbutton275.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj275inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_140280_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_291&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 879px; top: 592px; width: 44px; height: 44px; z-index: 23; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"275",
	htmlId:		"tobj275",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Back",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Previous',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_types_of_term_life.html',false,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[879,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_291&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_293\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_293&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_295\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_295&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_140280_43_297\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_43_297&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Back","titleValue":"Back"}
};
text140281.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink140304()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 1;",
	cssClasses:	"",
	id:		"140281",
	htmlId:		"tobj140281",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140282.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140282",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape140283.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140283inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 331)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140283",
	htmlId:		"tobj140283",
	bInsAnc:	0,
	cwObj:		{
		"name":	"WhiteBackground"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape140284.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140284inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_140280_315\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(504.5 331)\" style=\"\">\n	<pattern id=\"SVGID_140280_315\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_140280_315&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140284",
	htmlId:		"tobj140284",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape140285.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140285inner\"><svg viewBox=\"0 0 919 529\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(459.5 264.5)\" style=\"\">\n	<path d=\"M 0 0 L 909 0 L 909 519 L 0 519 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 10; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-454.5, -259.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(459.5 264.5)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 45px; top: 88px; width: 919px; height: 529px; z-index: 4; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140285",
	htmlId:		"tobj140285",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Background"
	},
	objData:	{"a":[0,544,0,[44.99999999999994,88.00000000000011,919,529]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":50,"y":93,"width":919,"height":529},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text140286.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 893px; min-height: 125px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 883px; min-height: 115px;\"><h1><p style=\"text-align: center;\" lang=\"en\"><strong><span style=\"color: rgb(0, 0, 0); font-family: &quot;fira sans&quot;, sans-serif; font-size:60pt;\">Who Buys Term Life?</span></strong></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 54px; top: 90px; width: 893px; height: 125px; z-index: 5;",
	cssClasses:	"",
	id:		"140286",
	htmlId:		"tobj140286",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,32,0,[54,90,893,125]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":54,"y":90,"width":893,"height":125},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image140339.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj140339Img\" src=\"images/Who%20Buys%20Term%20Life%20GRAPH%20Ver%202.jpg\" alt=\"Who Buys Term Life GRAPH Ver 2\" title=\"Who Buys Term Life GRAPH Ver 2\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 706px; height: 411px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 154px; top: 189px; width: 706px; height: 411px; z-index: 6; border-radius: 0px;",
	cssClasses:	"",
	id:		"140339",
	htmlId:		"tobj140339",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Who Buys Term Life GRAPH Ver 2"
	},
	objData:	{"a":[0,288,0,[154,189,706,411]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":154,"y":189,"width":706,"height":411}}
};
shape140954.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140954inner\"><svg viewBox=\"0 0 749 63\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 31.5)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 63 L 0 63 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -31.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 31.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 190px; width: 749px; height: 63px; z-index: 7; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140954",
	htmlId:		"tobj140954",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 1 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:1000,name:'OnPageShowHide',actItem:function(){ shape140954.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,190.00000000000009,749,63]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":190,"width":749,"height":63},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 1 Rectangle","titleValue":"Reveal 1 Rectangle"}
};
shape140959.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140959inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 253px; width: 749px; height: 64px; z-index: 8; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140959",
	htmlId:		"tobj140959",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 2 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:2000,name:'OnPageShowHide',actItem:function(){ shape140959.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,253.00000000000009,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":253,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 2 Rectangle","titleValue":"Reveal 2 Rectangle"}
};
shape140964.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140964inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 315px; width: 749px; height: 64px; z-index: 9; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140964",
	htmlId:		"tobj140964",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 3 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:3000,name:'OnPageShowHide',actItem:function(){ shape140964.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,315.0000000000001,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":315,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 3 Rectangle","titleValue":"Reveal 3 Rectangle"}
};
shape140969.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140969inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 379px; width: 749px; height: 64px; z-index: 10; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140969",
	htmlId:		"tobj140969",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 4 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:4000,name:'OnPageShowHide',actItem:function(){ shape140969.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,379.0000000000001,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":379,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 4 Rectangle","titleValue":"Reveal 4 Rectangle"}
};
shape140974.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140974inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 441px; width: 749px; height: 64px; z-index: 11; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140974",
	htmlId:		"tobj140974",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 5 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:5000,name:'OnPageShowHide',actItem:function(){ shape140974.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,441.0000000000001,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":441,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 5 Rectangle","titleValue":"Reveal 5 Rectangle"}
};
shape140979.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140979inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 151px; top: 500px; width: 749px; height: 64px; z-index: 12; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140979",
	htmlId:		"tobj140979",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 6 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:6000,name:'OnPageShowHide',actItem:function(){ shape140979.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[151,500.0000000000001,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":151,"y":500,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 6 Rectangle","titleValue":"Reveal 6 Rectangle"}
};
shape140984.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140984inner\"><svg viewBox=\"0 0 77 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(38.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 77 0 L 77 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-38.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(38.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 240px; top: 507px; width: 77px; height: 64px; z-index: 13; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140984",
	htmlId:		"tobj140984",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 6 Square",
		"arChld":
	[
		{type:6,on:11,delay:6000,name:'OnPageShowHide',actItem:function(){ shape140984.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[240,507,77,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":240,"y":507,"width":77,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 6 Square","titleValue":"Reveal 6 Square"}
};
shape140989.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140989inner\"><svg viewBox=\"0 0 749 64\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(374.5 32)\" style=\"\">\n	<path d=\"M 0 0 L 749 0 L 749 64 L 0 64 L 0 0 Z\" style=\"stroke: rgb(221, 221, 221); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-374.5, -32) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(374.5 32)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 91px; top: 536px; width: 749px; height: 64px; z-index: 14; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140989",
	htmlId:		"tobj140989",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Reveal 7 Rectangle",
		"arChld":
	[
		{type:6,on:11,delay:1000,name:'OnPageShowHide',actItem:function(){ shape140989.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,32,0,[91,536.0000000000001,749,64]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":91,"y":536,"width":749,"height":64},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Reveal 7 Rectangle","titleValue":"Reveal 7 Rectangle"}
};
shape141299.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj141299inner\"><svg viewBox=\"0 0 292 13\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(146 6.5)\" style=\"\">\n	<path d=\"M 0 0 L 292 0 L 292 13 L 0 13 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35); pointer-events: auto;\" transform=\"translate(0 0) translate(-146, -6.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(146 7)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 352px; top: 647px; width: 292px; height: 13px; z-index: 15; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"141299",
	htmlId:		"tobj141299",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,32,0,[352,647,292,13]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":352,"y":647,"width":292,"height":13},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle","titleValue":"Rectangle"}
};
text141303.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 16;",
	cssClasses:	"",
	id:		"141303",
	htmlId:		"tobj141303",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	8
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Nav%20Button%20Left.png","images/Nav%20Button%20Right.png","images/Who%20Buys%20Term%20Life%20GRAPH%20Ver%202.jpg","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];
