if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.53664e-12px; width: 1009px; height: 80px; z-index: 22; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.5366375666635577e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.53664e-12px; width: 1009px; height: 80px; z-index: 23; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.5366375666635577e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 5.96856e-13px; width: 229px; height: 80px; z-index: 24; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999997,5.968558980384842e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 25;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 26; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
text139771.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink139772()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 1;",
	cssClasses:	"",
	id:		"139771",
	htmlId:		"tobj139771",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og138173.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138173",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og138177.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138177",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
image141034.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141034Img\" src=\"images/Background%20-%20Test%20Questions.JPG\" alt=\"Background - Test Questions\" title=\"Background - Test Questions\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 672px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: -150px; width: 1009px; height: 672px; z-index: 2; border-radius: 0px;",
	cssClasses:	"",
	id:		"141034",
	htmlId:		"tobj141034",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background - Test Questions"
	},
	objData:	{"a":[0,288,0,[0,-150,1009,672]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":-150,"width":1009,"height":672}}
};
shape138179.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138179inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 331)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138179",
	htmlId:		"tobj138179",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Color"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138180.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138180inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_138172_341\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(504.5 331)\" style=\"\">\n	<pattern id=\"SVGID_138172_341\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_138172_341&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 4; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138180",
	htmlId:		"tobj138180",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138181.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138181inner\"><svg viewBox=\"0 0 1009 485\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 242.5)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 485 L 0 485 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -242.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 242.5)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"7.56\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 177px; width: 1009px; height: 485px; z-index: 5; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138181",
	htmlId:		"tobj138181",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Bottom"
	},
	objData:	{"a":[0,4640,0,[-5.684341886080802e-14,177.0000000000001,1009,485]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":485,"width":1009,"height":485},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text138192.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 938px; min-height: 52px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 938px; min-height: 52px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.273;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:28pt;\">5/5 | MULTIPLE RESPONSE</span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 44px; top: 107px; width: 938px; height: 52px; z-index: 6;",
	cssClasses:	"",
	id:		"138192",
	htmlId:		"tobj138192",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Question Count"
	},
	objData:	{"a":[0,32,0,[44,107,938,52]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":44,"y":107,"width":938,"height":52},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
qu138182.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu138182",
	bInsAnc:	undefined,
	cwObj:		{
		"crLineColor":	"",
		"questType":	14,
		"dwQuestFlags":	3,
		"doImmFeedback":	0,
		"maxAllowedAttempts":	0,
		"arrAns":	["\\u0052\\u0065\\u0070\\u006C\\u0061\\u0063\\u0065\\u0020\\u0049\\u006E\\u0063\\u006F\\u006D\\u0065\\u002C\\u0046\\u0069\\u006E\\u0061\\u006C\\u0020\\u0045\\u0078\\u0070\\u0065\\u006E\\u0073\\u0065\\u0073\\u002C\\u0042\\u0075\\u0073\\u0069\\u006E\\u0065\\u0073\\u0073\\u0020\\u0043\\u006F\\u006E\\u0074\\u0069\\u006E\\u0075\\u0061\\u0074\\u0069\\u006F\\u006E\\u002C\\u004D\\u006F\\u0072\\u0074\\u0067\\u0061\\u0067\\u0065\\u0020\\u0050\\u0072\\u006F\\u0074\\u0065\\u0063\\u0074\\u0069\\u006F\\u006E"],
		"correctFeedbackFunc":	"action138182_1",
		"incorrectFeedbackFunc":	"action138182_2",
		"attemptsFeedbackFunc":	0,
		"varQuest":	VarQuestion_138182
	},
	objData:	{"a":[0,32,0,[]]}
};
text138206.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 435px; min-height: 382px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 435px; min-height: 382px;\"><p align=\"left\" lang=\"en\"><span style=\"font-size:36pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">There are many needs met by life insurance. Select all the reasons discussed in this module.</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 218px; width: 435px; height: 382px; z-index: 7;",
	cssClasses:	"",
	id:		"138206",
	htmlId:		"tobj138206",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[35,218,435,382]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":218,"width":435,"height":382},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138207.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 405px; min-height: 60px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 405px; min-height: 60px;\"><label for=\"rad138208\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:26pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">Replace Income</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 565px; top: 230px; width: 405px; height: 60px; z-index: 8;",
	cssClasses:	"",
	id:		"138207",
	htmlId:		"tobj138207",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[565,230,405,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":565,"y":230,"width":405,"height":60},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":525}
};
checkbox138208.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"checkbox\" id=\"rad138208\" name=\"rad138208\" value=\"Replace Income\" onclick=\"qu138182.questionUpdated(1);\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad138208\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/checkbox_unchecked.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 510px; top: 232px; width: 36px; height: 36px; z-index: 9;",
	cssClasses:	"",
	id:		"138208",
	htmlId:		"tobj138208",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[510,232,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":510,"y":232,"width":36,"height":36},"formType":5,"dwFormFlags":0}
};
text138209.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 405px; min-height: 60px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 405px; min-height: 60px;\"><label for=\"rad138210\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:26pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">Final Expenses</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 565px; top: 312px; width: 405px; height: 60px; z-index: 10;",
	cssClasses:	"",
	id:		"138209",
	htmlId:		"tobj138209",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[565,312,405,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":565,"y":312,"width":405,"height":60},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":575}
};
checkbox138210.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"checkbox\" id=\"rad138210\" name=\"rad138210\" value=\"Final Expenses\" onclick=\"qu138182.questionUpdated(1);\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad138210\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/checkbox_unchecked.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 510px; top: 314px; width: 36px; height: 36px; z-index: 11;",
	cssClasses:	"",
	id:		"138210",
	htmlId:		"tobj138210",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[510,314,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":510,"y":314,"width":36,"height":36},"formType":5,"dwFormFlags":0}
};
text138211.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 405px; min-height: 70px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 405px; min-height: 70px;\"><label for=\"rad138212\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:26pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">Business Continuation</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 565px; top: 397px; width: 405px; height: 70px; z-index: 12;",
	cssClasses:	"",
	id:		"138211",
	htmlId:		"tobj138211",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[565,397,405,70]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":565,"y":397,"width":405,"height":70},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":625}
};
checkbox138212.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"checkbox\" id=\"rad138212\" name=\"rad138212\" value=\"Business Continuation\" onclick=\"qu138182.questionUpdated(1);\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad138212\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/checkbox_unchecked.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 510px; top: 397px; width: 36px; height: 36px; z-index: 13;",
	cssClasses:	"",
	id:		"138212",
	htmlId:		"tobj138212",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[510,397,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":510,"y":397,"width":36,"height":36},"formType":5,"dwFormFlags":0}
};
text138216.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 405px; min-height: 60px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 405px; min-height: 60px;\"><label for=\"rad138217\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:26pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">Mortgage Protection</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 565px; top: 490px; width: 405px; height: 60px; z-index: 14;",
	cssClasses:	"",
	id:		"138216",
	htmlId:		"tobj138216",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 4 text"
	},
	objData:	{"a":[0,32,0,[565,490,405,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":565,"y":490,"width":405,"height":60},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":675}
};
checkbox138217.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"checkbox\" id=\"rad138217\" name=\"rad138217\" value=\"Mortgage Protection\" onclick=\"qu138182.questionUpdated(1);\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad138217\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/checkbox_unchecked.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 510px; top: 492px; width: 36px; height: 36px; z-index: 15;",
	cssClasses:	"",
	id:		"138217",
	htmlId:		"tobj138217",
	bInsAnc:	0,
	fieldsetId:	'fset138182',
	cwObj:		{
		"name":	"Choice 4 button"
	},
	objData:	{"a":[0,32,0,[510,492,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":510,"y":492,"width":36,"height":36},"formType":5,"dwFormFlags":0}
};
textbutton138190.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138190inner\"><svg viewBox=\"0 0 210 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(105 25)\" style=\"\">\n	<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(105 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 765px; top: 575px; width: 210px; height: 50px; z-index: 16; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138190",
	htmlId:		"tobj138190",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Question Submit Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu138182.processQuestion();

    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[765,575,210,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":765,"y":575,"width":210,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#28283C\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"SUBMIT","titleValue":"SUBMIT"}
};
og138193.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138193",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape138194.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138194inner\"><svg viewBox=\"0 0 950 425\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(475 212.5)\" style=\"\">\n	<path d=\"M 0 0 L 940 0 L 940 415 L 0 415 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 10; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-470, -207.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(475 212.5)\">\n		<text font-family=\"Pacifico\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"7.56\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 30px; top: 209px; width: 950px; height: 425px; z-index: 17; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138194",
	htmlId:		"tobj138194",
	bInsAnc:	0,
	cwObj:		{
		"name":	"White BG"
	},
	objData:	{"a":[0,512,0,[29.999999999999943,209.0000000000001,950,425]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":214,"width":950,"height":425},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
textbutton138195.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138195inner\"><svg viewBox=\"0 0 210 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(105 25)\" style=\"\">\n	<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(105 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 400px; top: 485px; width: 210px; height: 50px; z-index: 18; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138195",
	htmlId:		"tobj138195",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Continue Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcTestSurv',actItem:function(){ processTest(1);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32768,0,[400,485,210,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":400,"y":485,"width":210,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#000000\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"CONTINUE","titleValue":"CONTINUE"}
};
text138198.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 905px; min-height: 138px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 905px; min-height: 138px;\"><p align=\"center\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-size:48pt; font-family: &quot;Fira Sans&quot;, sans-serif;\"><strong><span style=\"color: rgb(0, 0, 0);\">CORRECT!</span></strong><span style=\"background-color: transparent; color: rgb(1, 1, 1);\"> </span></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 50px; top: 330px; width: 905px; height: 138px; z-index: 19;",
	cssClasses:	"",
	id:		"138198",
	htmlId:		"tobj138198",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Feedback Title Text"
	},
	objData:	{"a":[0,0,0,[50,330,905,138]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":50,"y":330,"width":905,"height":138},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138197.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 618px; min-height: 93px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 618px; min-height: 93px;\"><p align=\"center\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\" font-size:14pt; font-family:\'Fira Sans\', sans-serif; color:#000000;\">Other commons needs met by life insurance include estate planning, debt settlement, dependents\' support, and employee benefits.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 196px; top: 415px; width: 618px; height: 93px; z-index: 20;",
	cssClasses:	"",
	id:		"138197",
	htmlId:		"tobj138197",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Feedback Body Text"
	},
	objData:	{"a":[0,0,0,[196,415,618,93]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":196,"y":415,"width":618,"height":93},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text141357.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 21;",
	cssClasses:	"",
	id:		"141357",
	htmlId:		"tobj141357",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	21
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Background%20-%20Test%20Questions.JPG","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];
