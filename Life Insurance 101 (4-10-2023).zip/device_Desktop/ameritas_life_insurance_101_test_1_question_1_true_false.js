if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.05347e-12px; width: 1009px; height: 80px; z-index: 18; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.0534685063466895e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.05347e-12px; width: 1009px; height: 80px; z-index: 19; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,2.0534685063466895e-12,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 4.83169e-13px; width: 229px; height: 80px; z-index: 20; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999998,4.831690603168681e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 21;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 22; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
text139751.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink139752()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 1;",
	cssClasses:	"",
	id:		"139751",
	htmlId:		"tobj139751",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og138124.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138124",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og138027.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138027",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
image141014.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141014Img\" src=\"images/Background%20-%20Test%20Questions.JPG\" alt=\"Background - Test Questions\" title=\"Background - Test Questions\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 672px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: -150px; width: 1009px; height: 672px; z-index: 2; border-radius: 0px;",
	cssClasses:	"",
	id:		"141014",
	htmlId:		"tobj141014",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background - Test Questions"
	},
	objData:	{"a":[0,288,0,[0,-150,1009,672]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":-150,"width":1009,"height":672}}
};
shape138029.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138029inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 331)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.9;filter:alpha(opacity=90);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138029",
	htmlId:		"tobj138029",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Color"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138030.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138030inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_137941_333\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(504.5 331)\" style=\"\">\n	<pattern id=\"SVGID_137941_333\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_137941_333&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 4; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138030",
	htmlId:		"tobj138030",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-5.684341886080802e-14,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape138031.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138031inner\"><svg viewBox=\"0 0 1009 485\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 242.5)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 485 L 0 485 L 0 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -242.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 242.5)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"7.56\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -5.68434e-14px; top: 177px; width: 1009px; height: 485px; z-index: 5; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138031",
	htmlId:		"tobj138031",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_Bottom"
	},
	objData:	{"a":[0,4640,0,[-5.684341886080802e-14,177.0000000000001,1009,485]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":485,"width":1009,"height":485},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text138042.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 938px; min-height: 51px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 938px; min-height: 51px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.273;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-size:28pt; color: rgb(255, 255, 255); font-family: &quot;Fira Sans&quot;, sans-serif;\">1/5 | TRUE/FALSE </span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 44px; top: 107px; width: 938px; height: 51px; z-index: 6;",
	cssClasses:	"",
	id:		"138042",
	htmlId:		"tobj138042",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Question Count"
	},
	objData:	{"a":[0,32,0,[44,107,938,51]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":44,"y":107,"width":938,"height":51},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
qu137984.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu137984",
	bInsAnc:	undefined,
	cwObj:		{
		"crLineColor":	"",
		"questType":	1,
		"dwQuestFlags":	2,
		"doImmFeedback":	0,
		"maxAllowedAttempts":	0,
		"arrAns":	["\\u0054\\u0072\\u0075\\u0065"],
		"correctFeedbackFunc":	"action137984_1",
		"incorrectFeedbackFunc":	"action137984_2",
		"attemptsFeedbackFunc":	0,
		"varQuest":	VarQuestion_137984
	},
	objData:	{"a":[0,32,0,[]]}
};
text137992.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 596px; min-height: 391px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 596px; min-height: 391px;\"><p align=\"left\" lang=\"en\"><span style=\"font-size:36pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">Generally, life insurance coverage is grouped into one of two categories: temporary or permanent.</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 218px; width: 596px; height: 391px; z-index: 7;",
	cssClasses:	"",
	id:		"137992",
	htmlId:		"tobj137992",
	bInsAnc:	0,
	fieldsetId:	'fset137984',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[35,218,596,391]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":218,"width":596,"height":391},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text137993.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 260px; min-height: 53px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 260px; min-height: 53px;\"><label for=\"rad137994\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:36pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">True</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 687px; top: 220px; width: 260px; height: 53px; z-index: 8;",
	cssClasses:	"",
	id:		"137993",
	htmlId:		"tobj137993",
	bInsAnc:	0,
	fieldsetId:	'fset137984',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[687,220,260,53]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":687,"y":220,"width":260,"height":53},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":525}
};
radio137994.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad137994\" name=\"rad137984\" value=\"True\" onclick=\"VarQuestion_137984.set(this.value);qu137984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 652px; top: 240px; width: 19px; height: 19px; z-index: 9;",
	cssClasses:	"",
	id:		"137994",
	htmlId:		"tobj137994",
	bInsAnc:	0,
	fieldsetId:	'fset137984',
	cwObj:		{
		"name":	"True button"
	},
	objData:	{"a":[0,160,0,[652,240,19,19]],"rcdOvr":{"res":0},"desktopRect":{"x":652,"y":240,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
text137995.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 260px; min-height: 60px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 260px; min-height: 60px;\"><label for=\"rad137996\" style=\"cursor:\"><p align=\"left\" lang=\"en\"><span style=\"font-size:36pt; color: rgb(0, 0, 0); font-family: &quot;Fira Sans&quot;, sans-serif;\">False</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 687px; top: 284px; width: 260px; height: 60px; z-index: 10;",
	cssClasses:	"",
	id:		"137995",
	htmlId:		"tobj137995",
	bInsAnc:	0,
	fieldsetId:	'fset137984',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[687,284,260,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":687,"y":284,"width":260,"height":60},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":575}
};
radio137996.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad137996\" name=\"rad137984\" value=\"False\" onclick=\"VarQuestion_137984.set(this.value);qu137984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 652px; top: 304px; width: 19px; height: 19px; z-index: 11;",
	cssClasses:	"",
	id:		"137996",
	htmlId:		"tobj137996",
	bInsAnc:	0,
	fieldsetId:	'fset137984',
	cwObj:		{
		"name":	"False button"
	},
	objData:	{"a":[0,32,0,[652,304,19,19]],"rcdOvr":{"res":0},"desktopRect":{"x":652,"y":304,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
textbutton138047.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138047inner\"><svg viewBox=\"0 0 210 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(105 25)\" style=\"\">\n	<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(105 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 765px; top: 575px; width: 210px; height: 50px; z-index: 12; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138047",
	htmlId:		"tobj138047",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Question Submit Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu137984.processQuestion();

    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[765,575,210,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":765,"y":575,"width":210,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#FFFFFF\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-40.86\" y=\"7.56\" fill=\"#28283C\">SUBMIT</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"SUBMIT","titleValue":"SUBMIT"}
};
og138110.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og138110",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
shape138111.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138111inner\"><svg viewBox=\"0 0 950 425\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(475 212.5)\" style=\"\">\n	<path d=\"M 0 0 L 940 0 L 940 415 L 0 415 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 10; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-470, -207.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(475 212.5)\">\n		<text font-family=\"Pacifico\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"7.56\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 30px; top: 209px; width: 950px; height: 425px; z-index: 13; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138111",
	htmlId:		"tobj138111",
	bInsAnc:	0,
	cwObj:		{
		"name":	"White BG"
	},
	objData:	{"a":[0,512,0,[29.999999999999943,209.0000000000001,950,425]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":214,"width":950,"height":425},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text138115.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 905px; min-height: 138px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 905px; min-height: 138px;\"><p align=\"center\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-size:48pt; font-family: &quot;Fira Sans&quot;, sans-serif;\"><strong><span style=\"color: rgb(0, 0, 0);\">CORRECT!</span></strong><span style=\"background-color: transparent; color: rgb(1, 1, 1);\"> </span></span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 50px; top: 330px; width: 905px; height: 138px; z-index: 14;",
	cssClasses:	"",
	id:		"138115",
	htmlId:		"tobj138115",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Feedback Title Text"
	},
	objData:	{"a":[0,0,0,[50,330,905,138]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":50,"y":330,"width":905,"height":138},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text138114.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 618px; min-height: 93px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 618px; min-height: 93px;\"><p align=\"center\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\" font-size:14pt; font-family:\'Fira Sans\', sans-serif; color:#000000;\">There are many types of life insurance but it may help to categorize them into either temporary coverage or permanent coverage.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 196px; top: 415px; width: 618px; height: 93px; z-index: 15;",
	cssClasses:	"",
	id:		"138114",
	htmlId:		"tobj138114",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Feedback Body Text"
	},
	objData:	{"a":[0,0,0,[196,415,618,93]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":196,"y":415,"width":618,"height":93},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton138112.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj138112inner\"><svg viewBox=\"0 0 210 50\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(105 25)\" style=\"\">\n	<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(105 25)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 400px; top: 485px; width: 210px; height: 50px; z-index: 16; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"138112",
	htmlId:		"tobj138112",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Continue Button",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('ameritas_life_insurance_101_test_1_question_2_multiple_choice.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32768,0,[400,485,210,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":400,"y":485,"width":210,"height":50},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(40, 40, 60); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#FFFFFF\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(105 25)\" style=\"\">\n\t<path d=\"M 25 0 L 185 0 A 25 25 0 0 1 210 25 L 210 25 A 25 25 0 0 1 185 50 L 25 50 A 25 25 0 0 1 0 25 L 0 25 A 25 25 0 0 1 25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-105, -25) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(105 25)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-55.52\" y=\"7.56\" fill=\"#000000\">CONTINUE</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"CONTINUE","titleValue":"CONTINUE"}
};
text141341.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 17;",
	cssClasses:	"",
	id:		"141341",
	htmlId:		"tobj141341",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	17
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Background%20-%20Test%20Questions.JPG","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];
