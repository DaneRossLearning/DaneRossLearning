if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try {
		if ( window.initGEV ) {
			initGEV(0, swipeLeft, swipeRight);
		}
	}
	catch ( e ) { if ( window.console ) window.console.log(e); }

	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
og137126.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og137126",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":false}
};
shape137124.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj137124inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 6.03961e-13px; width: 1009px; height: 80px; z-index: 28; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"137124",
	htmlId:		"tobj137124",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,6.039613253960852e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139832.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139832inner\"><svg viewBox=\"0 0 1009 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(26, 35, 47); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 6.03961e-13px; width: 1009px; height: 80px; z-index: 29; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139832",
	htmlId:		"tobj139832",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[0,6.039613253960852e-13,1009,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1009,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape139836.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj139836inner\"><svg viewBox=\"0 0 229 80\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(114.5 40)\" style=\"\">\n	<path d=\"M 0 0 L 229 0 L 229 80 L 0 80 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-114.5, -40) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(114.5 40)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-112.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 780px; top: 1.42109e-13px; width: 229px; height: 80px; z-index: 30; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"139836",
	htmlId:		"tobj139836",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Header Background"
	},
	objData:	{"a":[0,544,0,[779.9999999999999,1.4210854715202004e-13,229,80]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":780,"y":0,"width":229,"height":80},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text137125.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 787px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 777px; min-height: 47px;\"><p style=\"text-align:left\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; color: rgb(255, 255, 255); font-size:24pt;\">Life Insurance 101</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 11px; width: 787px; height: 57px; z-index: 31;",
	cssClasses:	"",
	id:		"137125",
	htmlId:		"tobj137125",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Course Title Text"
	},
	objData:	{"a":[0,32,0,[35,11,787,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":35,"y":11,"width":787,"height":57},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image141384.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj141384Img\" src=\"images/1-Logo-white-background.png\" alt=\"1-Logo-white-background\" title=\"1-Logo-white-background\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 200px; height: 58px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 795px; top: 10px; width: 200px; height: 58px; z-index: 32; border-radius: 0px;",
	cssClasses:	"",
	id:		"141384",
	htmlId:		"tobj141384",
	bInsAnc:	0,
	cwObj:		{
		"name":	"1-Logo-white-background"
	},
	objData:	{"a":[0,288,0,[795,10,200,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":795,"y":10,"width":200,"height":58}}
};
og270.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og270",
	bInsAnc:	undefined,
	objData:	{"a":[0,96,0,[]],"bReadLast":true}
};
textbutton281.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj281inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_139989_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_283&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 930px; top: 592px; width: 44px; height: 44px; z-index: 33; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"281",
	htmlId:		"tobj281",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Next',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_types_of_life_insurance.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[930,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":79,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_283\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_283&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_285\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_285&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_287\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_287&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_289\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Right.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_289&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Next","titleValue":"Next"}
};
textbutton275.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj275inner\"><svg viewBox=\"0 0 44 44\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(22 22)\" style=\"\">\n	<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_139989_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_291&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(22 22)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 879px; top: 592px; width: 44px; height: 44px; z-index: 34; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"275",
	htmlId:		"tobj275",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Back",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'GoTo_Previous',actItem:function(){ trivExitPage('ameritas_life_insurance_101_layouts_needs_met_by_life_insurance.html',false,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39200,0,[879,592,44,44]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":70,"width":44,"height":44},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_291\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_291&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(51, 51, 51); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_293\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_293&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_295\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_295&quot;); fill-rule: nonzero; opacity: 0.5; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.5;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(22 22)\" style=\"\">\n\t<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(0, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_139989_43_297\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"44\" height=\"44\" xlink:href=\"images/Nav%20Button%20Left.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 44 0 L 44 44 L 0 44 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_43_297&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-22, -22) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(22 22)\">\n\t\t<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Back","titleValue":"Back"}
};
og139991.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og139991",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og139994.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og139994",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
og140001.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140001",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape140013.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140013inner\"><svg viewBox=\"0 0 1009 662\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(504.5 331)\" style=\"\">\n	<path d=\"M 0 0 L 1009 0 L 1009 662 L 0 662 L 0 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-504.5, -331) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(504.5 331)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-502.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -82px; top: 1.13687e-13px; width: 1009px; height: 662px; z-index: 1; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140013",
	htmlId:		"tobj140013",
	bInsAnc:	0,
	cwObj:		{
		"name":	"WhiteBackground"
	},
	objData:	{"a":[0,544,0,[-82.00000000000006,1.1368683772161603e-13,1009,662]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":-82,"y":0,"width":1009,"height":662},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape140014.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140014inner\"><svg viewBox=\"0 0 1087 630\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><pattern id=\"SVGID_139989_311\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<g transform=\"translate(543.5 315)\" style=\"\">\n	<pattern id=\"SVGID_139989_311\" x=\"0\" y=\"0\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\">\n<image x=\"0\" y=\"0\" width=\"128\" height=\"128\" xlink:href=\"images/Fira%20Dot%20Pattern-Final.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 1087 0 L 1087 630 L 0 630 L 0 0 Z\" style=\"stroke: rgb(33, 179, 199); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_139989_311&quot;); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30); pointer-events: auto;\" transform=\"translate(0 0) translate(-543.5, -315) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(543.5 315)\">\n		<text font-family=\"\'Century Gothic\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.3;filter:alpha(opacity=30);\">\n			<tspan x=\"-541.5\" y=\"10.08\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: -82px; top: 33px; width: 1087px; height: 630px; z-index: 2; transform: rotate(180deg); overflow: visible; pointer-events: none;; behavior:url(-ms-transform.htc); -moz-transform:rotate(180deg) ; -webkit-transform:rotate(180deg) ; -o-transform:rotate(180deg) ; -ms-transform:rotate(180deg) ; filter: progid:DXImageTransform.Microsoft.Matrix(sizingMethod=\'auto expand\', M11=-1, M12=-1.2246467991473532e-16, M21=1.2246467991473532e-16, M22=-1) ; -ms-filter: progid:DXImageTransform.Microsoft.Matrix(sizingMethod=\'auto expand\', M11=-1, M12=-1.2246467991473532e-16, M21=1.2246467991473532e-16, M22=-1) ",
	cssClasses:	"",
	id:		"140014",
	htmlId:		"tobj140014",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Background_DotPattern"
	},
	objData:	{"a":[0,544,0,[-82,33.00000000000006,1087,630]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":180,"anchorX":50,"anchorY":50},"desktopRect":{"x":-82,"y":33,"width":1087,"height":630},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
shape140015.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140015inner\"><svg viewBox=\"0 0 709 520\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(354.5 260)\" style=\"\">\n	<path d=\"M 0 0 L 699 0 L 699 510 L 0 510 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 10; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-349.5, -255) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(354.5 260)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"7.56\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 35px; top: 105px; width: 709px; height: 520px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140015",
	htmlId:		"tobj140015",
	bInsAnc:	0,
	cwObj:		{
		"name":	"WhiteBG_PinkOL"
	},
	objData:	{"a":[0,2592,0,[34.99999999999994,105.00000000000011,709,520]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":969,"y":110,"width":709,"height":520},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
og140016.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140016",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
text140823.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 498px; min-height: 125px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 488px; min-height: 115px;\"><h1><p style=\"text-align: center;\" lang=\"en\"><strong><span style=\"font-size:48pt; color: rgb(0, 0, 0); font-family: &quot;fira sans&quot;;\"><span class='VarCurrentPageName'>" +  VarCurrentPageName.getValueForDisplay() + "</span></span></strong></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 80px; top: 255px; width: 498px; height: 125px; z-index: 4;",
	cssClasses:	"",
	id:		"140823",
	htmlId:		"tobj140823",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,32,0,[80,255,498,125]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":80,"y":255,"width":498,"height":125},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
og140019.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140019",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140020.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140020inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FFFFFF\">Debts</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 700px; top: 175px; width: 375px; height: 60px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140020",
	htmlId:		"tobj140020",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button1",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140020.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFira_C2R_Tab1.set('1');  triv$('span.VarFira_C2R_Tab1', getDisplayDocument()).html(VarFira_C2R_Tab1.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140029.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140096.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }},
		{type:6,on:2,delay:0,name:'OnMClkHide',actItem:function(){ text140823.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[700,175.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":175,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FFFFFF\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FC004F\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FFFFFF\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#28283C\">Debts</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Debts","titleValue":"Debts"}
};
textbutton140029.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140029inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-31.33\" y=\"7.56\" fill=\"#28283C\">Debts</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 700px; top: 175px; width: 375px; height: 60px; z-index: 6; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140029",
	htmlId:		"tobj140029",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button1_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideVisitedState',actItem:function(){ textbutton140029.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140029.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140096.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[700,175.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":175,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#28283C\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FC004F\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#FFFFFF\">Debts</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-31.33\" y=\"7.56\" fill=\"#ffffff\">Debts</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Debts","titleValue":"Debts"}
};
og140037.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140037",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140038.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140038inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FFFFFF\">Employee Benefits</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 700px; top: 285px; width: 375px; height: 60px; z-index: 7; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140038",
	htmlId:		"tobj140038",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button2",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140038.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFira_C2R_Tab2.set('1');  triv$('span.VarFira_C2R_Tab2', getDisplayDocument()).html(VarFira_C2R_Tab2.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140047.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140100.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }},
		{type:6,on:2,delay:0,name:'OnMClkHide',actItem:function(){ text140823.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[700,285.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":285,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FFFFFF\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FC004F\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FFFFFF\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#28283C\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Employee Benefits","titleValue":"Employee Benefits"}
};
textbutton140047.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140047inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-101.27\" y=\"7.56\" fill=\"#28283C\">Employee Benefits</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 700px; top: 285px; width: 375px; height: 60px; z-index: 8; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140047",
	htmlId:		"tobj140047",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button2_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideVisitedState',actItem:function(){ textbutton140047.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140047.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140100.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[700,285.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":285,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#28283C\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FC004F\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#FFFFFF\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-101.27\" y=\"7.56\" fill=\"#ffffff\">Employee Benefits</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Employee Benefits","titleValue":"Employee Benefits"}
};
og140055.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140055",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140056.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140056inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FFFFFF\">Final Expenses</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 700px; top: 395px; width: 375px; height: 60px; z-index: 9; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140056",
	htmlId:		"tobj140056",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button3",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140056.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFira_C2R_Tab3.set('1');  triv$('span.VarFira_C2R_Tab3', getDisplayDocument()).html(VarFira_C2R_Tab3.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140065.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140104.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }},
		{type:6,on:2,delay:0,name:'OnMClkHide',actItem:function(){ text140823.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[700,395.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":395,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FFFFFF\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FC004F\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FFFFFF\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#28283C\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Final Expenses","titleValue":"Final Expenses"}
};
textbutton140065.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140065inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-80.22\" y=\"7.56\" fill=\"#28283C\">Final Expenses</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 700px; top: 395px; width: 375px; height: 60px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140065",
	htmlId:		"tobj140065",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button3_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideVisitedState',actItem:function(){ textbutton140065.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140065.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140104.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[700,395.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":395,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#28283C\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FC004F\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#FFFFFF\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-80.22\" y=\"7.56\" fill=\"#ffffff\">Final Expenses</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Final Expenses","titleValue":"Final Expenses"}
};
og140073.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140073",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton140074.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140074inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FFFFFF\">Mortgage Protection</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 700px; top: 500px; width: 375px; height: 60px; z-index: 11; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140074",
	htmlId:		"tobj140074",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button4",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideNormalState',actItem:function(){ textbutton140074.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'EnableVisitedState',actItem:function(){ { VarFira_C2R_Tab4.set('1');  triv$('span.VarFira_C2R_Tab4', getDisplayDocument()).html(VarFira_C2R_Tab4.getValueForDisplay()); }
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140083.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140108.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }},
		{type:6,on:2,delay:0,name:'OnMClkHide',actItem:function(){ text140823.hide(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32800,0,[700,500.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":500,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(211, 34, 42); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FFFFFF\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FC004F\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FFFFFF\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#28283C\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Mortgage Protection","titleValue":"Mortgage Protection"}
};
textbutton140083.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj140083inner\"><svg viewBox=\"0 0 375 60\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(187.5 30)\" style=\"\">\n	<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(187.5 30)\">\n		<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-111.01\" y=\"7.56\" fill=\"#28283C\">Mortgage Protection</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 700px; top: 500px; width: 375px; height: 60px; z-index: 12; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"140083",
	htmlId:		"tobj140083",
	bInsAnc:	false,
	cwObj:		{
		"name":	"Button4_visited",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'RunHideContentAction',actItem:function(){ {og139994.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'HideVisitedState',actItem:function(){ textbutton140083.hide(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowVisitedStates',actItem:function(){ {og140001.issueActions(1001);}
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowSelectedState',actItem:function(){ textbutton140083.setState('null');
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'ShowTabContent',actItem:function(){ og140108.show(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:0,name:'xAPI_Statement',actItem:function(){ true }}
	]
	},
	objData:	{"a":[4,32768,0,[700,500.00000000000006,375,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":700,"y":500,"width":375,"height":60},"bTriggerScreenRdrOnShow":true,"svgDataNormal":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(212, 212, 216); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(40,40,60); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#28283C\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(254, 255, 255); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(252,0,79); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FC004F\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#FFFFFF\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(187.5 30)\" style=\"\">\n\t<path d=\"M 30 0 L 345 0 A 30 30 0 0 1 375 30 L 375 30 A 30 30 0 0 1 345 60 L 30 60 A 30 30 0 0 1 0 30 L 0 30 A 30 30 0 0 1 30 0 Z\" style=\"stroke: rgb(252, 0, 79); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(40, 40, 60); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-187.5, -30) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(187.5 30)\">\n\t\t<text font-family=\"Fira Sans\" font-size=\"23.9999994\" font-weight=\"bold\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-111.01\" y=\"7.56\" fill=\"#ffffff\">Mortgage Protection</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"Mortgage Protection","titleValue":"Mortgage Protection"}
};
og140096.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140096",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
text140097.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 559px; min-height: 55px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 559px; min-height: 55px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><strong><span style=\" font-size:24pt; font-family:\'Fira Sans\', sans-serif; color:#000000; \">DEBTS</span></strong></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 112px; top: 462px; width: 559px; height: 55px; z-index: 13;",
	cssClasses:	"",
	id:		"140097",
	htmlId:		"tobj140097",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader"
	},
	objData:	{"a":[0,0,0,[112,462,559,55]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":112,"y":462,"width":559,"height":55},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140098.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 551px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 551px; min-height: 100px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; font-size: 18.6667px; color: rgb(0, 0, 0);\">One fear some&nbsp;people have is leaving their family with debt. A life insurance death benefit can help the family pay off those debts.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 112px; top: 507px; width: 551px; height: 100px; z-index: 14;",
	cssClasses:	"",
	id:		"140098",
	htmlId:		"tobj140098",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content"
	},
	objData:	{"a":[0,0,0,[112,507,551,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":112,"y":507,"width":551,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image140260.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj140260Img\" src=\"images/Debts%20(Reasons)%20-%20stressed-senior-man-in-casual-clothes-sitting-at-t.jpg\" alt=\"Debts (Reasons) - stressed-senior-man-in-casual-clothes-sitting-at-t\" title=\"Debts (Reasons) - stressed-senior-man-in-casual-clothes-sitting-at-t\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 485px; height: 287px;\">",
	cssText:	"visibility: hidden; position: absolute; left: 112px; top: 154px; width: 485px; height: 287px; z-index: 15; border-radius: 0px;",
	cssClasses:	"",
	id:		"140260",
	htmlId:		"tobj140260",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Debts (Reasons) - stressed-senior-man-in-casual-clothes-sitting-at-t"
	},
	objData:	{"a":[0,256,0,[112,154,485,287]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":112,"y":154,"width":485,"height":287}}
};
og140100.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140100",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
text140101.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 559px; min-height: 55px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 559px; min-height: 55px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><strong><span style=\" font-size:24pt; font-family:\'Fira Sans\', sans-serif; color:#000000; \">EMPLOYEE BENEFITS</span></strong></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 113px; top: 465px; width: 559px; height: 55px; z-index: 16;",
	cssClasses:	"",
	id:		"140101",
	htmlId:		"tobj140101",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader"
	},
	objData:	{"a":[0,0,0,[113,465,559,55]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":113,"y":465,"width":559,"height":55},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140102.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 551px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 551px; min-height: 100px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; font-size: 18.6667px; color: rgb(0, 0, 0);\">Life insurance is a popular benefit offered by employers. This may include term coverage as part of a group policy as well as individual coverage on key employees.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 113px; top: 510px; width: 551px; height: 100px; z-index: 17;",
	cssClasses:	"",
	id:		"140102",
	htmlId:		"tobj140102",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content"
	},
	objData:	{"a":[0,0,0,[113,510,551,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":113,"y":510,"width":551,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image140262.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj140262Img\" src=\"images/Employee%20Benefits%20(Reasons)%20cropped-view-of-recruiter-and-employee-shaking-han.jpg\" alt=\"Employee Benefits (Reasons) cropped-view-of-recruiter-and-employee-shaking-han\" title=\"Employee Benefits (Reasons) cropped-view-of-recruiter-and-employee-shaking-han\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 487px; height: 289px;\">",
	cssText:	"visibility: hidden; position: absolute; left: 112px; top: 155px; width: 487px; height: 289px; z-index: 18; border-radius: 0px;",
	cssClasses:	"",
	id:		"140262",
	htmlId:		"tobj140262",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Employee Benefits (Reasons) cropped-view-of-recruiter-and-employee-shaking-han"
	},
	objData:	{"a":[0,256,0,[112,155,487,289]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":112,"y":155,"width":487,"height":289}}
};
og140104.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140104",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
text140105.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 559px; min-height: 55px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 559px; min-height: 55px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><strong><span style=\" font-size:24pt; font-family:\'Fira Sans\', sans-serif; color:#000000; \">FINAL EXPENSE</span></strong></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 121px; top: 462px; width: 559px; height: 55px; z-index: 19;",
	cssClasses:	"",
	id:		"140105",
	htmlId:		"tobj140105",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab3"
	},
	objData:	{"a":[0,0,0,[121,462,559,55]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":121,"y":462,"width":559,"height":55},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140106.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 551px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 551px; min-height: 100px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; font-size: 18.6667px; color: rgb(0, 0, 0);\">End of life expenses often include funeral or burial costs, but may also help pay medical bills or estate taxes.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 121px; top: 507px; width: 551px; height: 100px; z-index: 20;",
	cssClasses:	"",
	id:		"140106",
	htmlId:		"tobj140106",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab3"
	},
	objData:	{"a":[0,0,0,[121,507,551,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":121,"y":507,"width":551,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image140264.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj140264Img\" src=\"images/Final%20Expense%20(Reasons)%20selective-focus-of-senior-man-hugging-woman-near-t.jpg\" alt=\"Final Expense (Reasons) selective-focus-of-senior-man-hugging-woman-near-t\" title=\"Final Expense (Reasons) selective-focus-of-senior-man-hugging-woman-near-t\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 486px; height: 288px;\">",
	cssText:	"visibility: hidden; position: absolute; left: 120px; top: 160px; width: 486px; height: 288px; z-index: 21; border-radius: 0px;",
	cssClasses:	"",
	id:		"140264",
	htmlId:		"tobj140264",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Final Expense (Reasons) selective-focus-of-senior-man-hugging-woman-near-t"
	},
	objData:	{"a":[0,256,0,[120,160,486,288]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":120,"y":160,"width":486,"height":288}}
};
og140108.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og140108",
	bInsAnc:	undefined,
	objData:	{"a":[0,0,0,[]],"bReadLast":false}
};
text140109.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 559px; min-height: 55px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 559px; min-height: 55px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><strong><span style=\" font-size:24pt; font-family:\'Fira Sans\', sans-serif; color:#000000; \">MORTGAGE PROTECTION</span></strong></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 101px; top: 449px; width: 559px; height: 55px; z-index: 22;",
	cssClasses:	"",
	id:		"140109",
	htmlId:		"tobj140109",
	bInsAnc:	0,
	cwObj:		{
		"name":	"ContentHeader_Tab4"
	},
	objData:	{"a":[0,0,0,[101,449,559,55]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":101,"y":449,"width":559,"height":55},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text140110.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 551px; min-height: 100px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 551px; min-height: 100px;\"><p align=\"left\" style=\"margin-left:0px;text-indent:0px;line-height:1.107;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span style=\"font-family: &quot;Fira Sans&quot;, sans-serif; font-size: 18.6667px; color: rgb(0, 0, 0);\">One of the larger monthly expenses in many families is the mortgage payment. Proceeds from a life insurance death benefit could be used to pay off some or all of an outstanding mortgage balance.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 101px; top: 494px; width: 551px; height: 100px; z-index: 23;",
	cssClasses:	"",
	id:		"140110",
	htmlId:		"tobj140110",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Content_Tab4"
	},
	objData:	{"a":[0,0,0,[101,494,551,100]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":101,"y":494,"width":551,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
image140266.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj140266Img\" src=\"images/Mortgage%20Insurnace%20(Reasons)%20new-house.jpg\" alt=\"Mortgage Insurnace (Reasons) new-house\" title=\"Mortgage Insurnace (Reasons) new-house\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 488px; height: 288px;\">",
	cssText:	"visibility: hidden; position: absolute; left: 100px; top: 147px; width: 488px; height: 288px; z-index: 24; border-radius: 0px;",
	cssClasses:	"",
	id:		"140266",
	htmlId:		"tobj140266",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Mortgage Insurnace (Reasons) new-house"
	},
	objData:	{"a":[0,256,0,[100,147,488,288]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":100,"y":147,"width":488,"height":288}}
};
shape141279.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj141279inner\"><svg viewBox=\"0 0 292 13\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(146 6.5)\" style=\"\">\n	<path d=\"M 0 0 L 292 0 L 292 13 L 0 13 L 0 0 Z\" style=\"stroke: rgb(211, 34, 42); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35); pointer-events: auto;\" transform=\"translate(0 0) translate(-146, -6.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(146 7)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity:0.35;filter:alpha(opacity=35);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#000000\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 352px; top: 647px; width: 292px; height: 13px; z-index: 25; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"141279",
	htmlId:		"tobj141279",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,32,0,[352,647,292,13]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":352,"y":647,"width":292,"height":13},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle","titleValue":"Rectangle"}
};
text141283.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 313px; min-height: 28px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 303px; min-height: 18px;\"><p lang=\"en\"><span style=\"font-size:8pt; color: rgb(0, 0, 0); font-family: undefined, sans-serif;\"><span style=\"font-family: Arial, sans-serif;\">For </span><span style=\"font-family: Arial, sans-serif;\">financial professional </span><span style=\"font-family: Arial, sans-serif;\">use only. Not for use with clients. </span></span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 356px; top: 640px; width: 313px; height: 28px; z-index: 26;",
	cssClasses:	"",
	id:		"141283",
	htmlId:		"tobj141283",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Financial Pro Use Only Disclaimer"
	},
	objData:	{"a":[0,32,0,[356,640,313,28]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":356,"y":640,"width":313,"height":28},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
text139990.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 50px; min-height: 50px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 50px; min-height: 50px;\"><h1><p align=\"left\" style=\"margin-left:0px;text-indent:0px;margin-top:0px;margin-bottom:0px;\" lang=\"en\"><span><a href=\"javascript:hyperlink140112()\" style=\"cursor: pointer;\"><span style=\" font-size:12pt; font-family:\'Arial\', sans-serif; color:#0000ff; \"><u>SKIP</u></span></a><span style=\"background-color: transparent; color: rgb(1, 1, 1); font-size:12pt; font-family: &quot;Oswald Light&quot;, sans-serif;\"> </span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 50px; height: 50px; z-index: 27;",
	cssClasses:	"",
	id:		"139990",
	htmlId:		"tobj139990",
	bInsAnc:	0,
	cwObj:		{
		"name":	"SkipNav"
	},
	objData:	{"a":[0,32,0,[0,0,50,50]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":50,"height":50},"dwTextFlags":65536,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":true,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	focusColor:	"#ff9900",
	focusWidth:	2,
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"1.25","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	5
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/Fira%20Dot%20Pattern-Final.png","images/Nav%20Button%20Left.png","images/Nav%20Button%20Right.png","images/Debts%20(Reasons)%20-%20stressed-senior-man-in-casual-clothes-sitting-at-t.jpg","images/Employee%20Benefits%20(Reasons)%20cropped-view-of-recruiter-and-employee-shaking-han.jpg","images/Final%20Expense%20(Reasons)%20selective-focus-of-senior-man-hugging-woman-near-t.jpg","images/Mortgage%20Insurnace%20(Reasons)%20new-house.jpg","images/1-Logo-white-background.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#ffffff","",0,0,1];
